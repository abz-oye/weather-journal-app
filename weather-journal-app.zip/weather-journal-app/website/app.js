/* Global Variables */
let baseURL = 'http://api.openweathermap.org/data/2.5/forecast?zip=';
let apiKey = '&appid=a9cf36c6ddb26e8eeb97cf34bbfd9c19';

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();

document.getElementById('generate').addEventListener('click', action);

function action(e) {
  // const feelings = document.getElementById('feelings').value;
  const zip = document.getElementById('zip').value;
  const feelings = document.getElementById('feelings').value;

  getWeather(baseURL, zip, apiKey)
  .then(function(data) {
    console.log(data)
    postData('/body', {temp:data.main.temp, date:newDate, content:data})
    .then(updateUI);
  })
};

// Get weather function
const getWeather = async (baseURL, zip, apiKey) => {
  const res = await fetch(baseURL+zip+apiKey);
  try {
    const data = await res.json();
    return data;
  }
  catch(error) {
    console.log('error', error);
  }
};

const postData = async (url='', data={})=>{
  console.log(data);
  const response = await fetch(url, {
      method:'POST',
      credentials: 'same-origin',
      headers: {'Content-Type': 'application/json',},
      body: JSON.stringfy(data)
  });
  try {
      const newData = await response.json();
      console.log(data);
      return newData
  } catch(error) {
      console.log('error', error);
  }
};

const updateUI = async () => {
  const request = await fetch('/all');
  try{
    const allData = await request.json();
    document.getElementById('date').innerHTML = `Date: ${allData[0].date}`;
    document.getElementById('temp').innerHTML = `Tempreture: ${allData[0].temp}`;
    document.getElementById('content').innerHTML = `I am feeling ${allData[0].content}`;

  }
  catch(error){
    console.log("error", error);
  }
}
